(function() {

    angular.module('app')
        .controller('AddBookController', AddBookController);

    function AddBookController() {

    }

}());