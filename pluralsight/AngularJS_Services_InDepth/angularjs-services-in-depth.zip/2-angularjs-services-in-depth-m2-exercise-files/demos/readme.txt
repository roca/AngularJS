To host the BookLogger web application you will need to install node.js from the following site:

http://nodejs.org/

Once you have installed node, you may start the web server for the application in a terminal by going to the "BookLogger" directory and typing the following:

node server.js

That will start the webserver running on port 3000. You may then browse to the application using the following URL:

http://localhost:3000/