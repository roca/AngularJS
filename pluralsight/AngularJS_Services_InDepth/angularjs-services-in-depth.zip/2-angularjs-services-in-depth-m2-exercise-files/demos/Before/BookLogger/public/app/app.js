(function() {

    angular.module('app', []);

}());