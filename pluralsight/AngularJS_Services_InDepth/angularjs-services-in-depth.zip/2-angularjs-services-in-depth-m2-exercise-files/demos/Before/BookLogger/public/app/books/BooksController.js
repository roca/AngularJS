(function() {

    angular.module('app')
        .controller('BooksController', BooksController);


    function BooksController() {

        var vm = this;

    }


}());